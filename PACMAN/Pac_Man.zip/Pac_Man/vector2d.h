#ifndef VECTOR2D_H
#define VECTOR2D_H


class vector2D
{

public:
    float x;
    float y;
    vector2D();
    vector2D(float x_, float y_);

    vector2D& Add(const vector2D& vec);
    vector2D& Subtract(const vector2D& vec);
    vector2D& Multiply(const vector2D& vec);
    vector2D& Divide(const vector2D& vec);

    friend vector2D& operator+(vector2D& v1, const vector2D& v2);
    friend vector2D& operator-(vector2D& v1, const vector2D& v2);
    friend vector2D& operator+(vector2D& v1, const vector2D& v2);
    friend vector2D& operator/(vector2D& v1, const vector2D& v2);

    vector2D& operator+=(const vector2D& vec);
    vector2D& operator-=(const vector2D& vec);
    vector2D& operator*=(const vector2D& vec);
    vector2D& operator/=(const vector2D& vec);



};

#endif // VECTOR2D_H

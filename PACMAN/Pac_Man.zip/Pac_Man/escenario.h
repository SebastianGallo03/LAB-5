#ifndef ESCENARIO_H
#define ESCENARIO_H


class escenario
{
public:
    int i,j;

    escenario();
};

#endif // ESCENARIO_H

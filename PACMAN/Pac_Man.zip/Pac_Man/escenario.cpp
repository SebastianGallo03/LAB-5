#include "escenario.h"

escenario::escenario()
{

}
